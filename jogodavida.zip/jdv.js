var celula = 12;
var celulaviva = "deepskyblue";
var animação = false;
var lacoativo;
var fps = 20;
var intervalo = 1000 / fps;
var size = 300;
var lado = 30;
var borda = 1;
function desenha() {
	var canvas = document.getElementById('tela');
	if (canvas.getContext) {
		var ctx = canvas.getContext('2d');
		ctx.fillStyle = 'gainsboro';
		ctx.lineWidth = borda;
		ctx.strokeStyle = 'black';
		for (let y = 0; y < size; y += lado) {
		for (let x = 0; x < size; x += lado) {
		ctx.rect(x + borda, y + borda, lado - (borda * 2), lado - (borda * 2));
		ctx.fill();
		ctx.stroke();
		}
		}
	}
}
function celula(fileira, coluna){
	this.fileira = fileira;
	this.coluna = coluna
	this.viva = false
	this.vivanaproxima = false
}
function vizinhasvivas(fileira, coluna){
	var vizinhaviva = 0
	for (var f = fileira - 1; f <= fileira + 1; f++){
		for (var c = coluna - 1; c <= coluna + 1; c++){
			if (!(f == fileira && c == coluna)){
				if (f >= 0 && f < this.fileiras && c >= 0 && c < this.colunas){
					if (this.celulas[f][c].viva){
						vizinhaviva++;
					}
				}
			}
		}
	}
}
function vivanaproximageração(fileira,coluna){
	var vizinhavivas = this.contarvizinhasvivas(fileira,coluna);
	var celula = this.celula[fileira][coluna];
	var vivanaproxima;
	if (this.celula[fileira][coluna].viva) {
		if (vizinhaviva == 2 || vizinhaviva == 3){
			vivanaproximageração = true;

		} else {
			vivanaproximageração = false;
		}
	} else {
		if(vizinhaviva == 3){
			vivanaproximageração = true;
		} else {
			vivanaproximageração = false;
		}
	}
	celula.vivanaproximageração = vivanaproximageração;
	return vivanaproximageração;

}
function proximag(){
	var f;
	var c; 
	for (f = 0; f < this.fileiras; f++){
		for (c = 0; c < this.colunas; c++)
			this.vivanaproxima(f,c)
	}
	for (f = 0; f<this.fileiras;f++){
		for(c = 0; c< this.colunas; c++){
			this.celulas[f][c].viva = this.celula[f][c].vivanaproxima;
		}
	}
}
